﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Common02
{
    internal class TypeB : TypeA
    {
        public TypeB()
        {
             // H is Not Inhearited
            // X is Inheritied As Private
             // Y is Inheritied As Private
            // Z is Inheritied As Internal
        }


    }
}
