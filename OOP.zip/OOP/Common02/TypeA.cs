﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Common02
{
    internal class TypeA
    {
        private protected int X; // private
        protected int Y; // private
         internal protected int Z; // interal
    }
}
