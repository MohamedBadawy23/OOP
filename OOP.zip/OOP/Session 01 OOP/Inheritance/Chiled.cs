﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Session_01_OOP.Inheritance
{
    internal class Chiled :Parent
    {
        public int Z {  get; set; }
         public Chiled(int _X, int _Y, int _Z):base(_X,_Y)/*Constructor Chaining*/
        {
            Z = _Z;
        }

        public override string ToString()
        {
            return $" X = {X}\n Y = {Y} \n Z = {Z}";
        }
    }
}
