﻿using System;
using Session_01_OOP.Binding;

//using Common;
using Session_01_OOP.Encapsulation;
using Session_01_OOP.Inheritance;
using Session_01_OOP.Overriding;
using Session_01_OOP.Binding;
namespace Session_01_OOP
{
    internal class Program
    {
        #region  Overloading
        public static int Sum(int X, int Y)
        {
            return X + Y;
        }
         public static int  Sum ( int X,int Y , int Z)
        {

        return X + Y + Z;
        }
         public static  double Sum (double X, double Y)
        {
            return X + Y;
        }
         public static double Sum ( double X , int Y)
        {
            return X + Y;
        }
         public static double Sum (int X, double Y)
        {
            return X + Y;
        }


        #endregion

        #region  Overriding
         public  static void ProcessEmployee( Employee02 employee)//  employee= new FullTime Employee
        {
             if ( employee is not null)
            {
                employee.MyFun01();// Static Binding // Iam Employee 
                employee.MyFun02();// Dinamic Binding //
            }
        }
        //public static void ProcessEmployee(PartTimeEmployee employee)//employee= new PartTime Employee
        //{
        //    if (employee is not null)
        //    {
        //        employee.MyFun01();
        //        employee.MyFun02();
        //    }
        //}
        #endregion

        static void Main(string[] args)
        {
            #region Session 01
            #region Access Modifiers
            //- Access Modifiers 
            //- What is OOP
            //- Encapsulation
            //- Class
            //- Class vs Struct 
            //TypeA obj = new TypeA();
            ////obj.X = 10;// Invalid => Due To Itis Protection Level "Private"
            ////obj.Y = 20;
            //obj.Z = 50;
            #endregion
            #region  Encapsulation
            //Employee employee = new Employee(10,"Rana",4000);
            //// employee.EmpId = 20;// set Id directly Though Atrribute 
            ////// employee.SetName("Ahmedd"); // Set Name  Using Setter Method Not Attribute 
            //// Console.WriteLine(employee.EmpId);// Get Id Directly Through Attribute
            //// Console.WriteLine(employee.GetName());
            ////Console.WriteLine(employee.ToString());
            //employee.Salary = 8000;// Set Salary Using Property

            //Console.WriteLine(employee.Salary); //GET Salary Using Property

            #endregion
            #region  Class
            Car C1;
            // Declare For Refernce From Type Car 
            // C1 Can Refer To Object From Type CAR
            // Clr Will Alocate 4 Bytes For Refernce In Stack
            // Zero Bytes At Heap
            // C1 = new Car(10, "bmw");
            // new:
            //1- Allocate Required bytes At Heap
            //2- Intialize Allocated Bytes At Heap With Default Value 
            //3- Call User Defined Constructor if exists
            //4- Assign Refernce C1 To Allocated Object At Heap
            //----------------------
            //Console.WriteLine(C1);




            #endregion
            #endregion
            #region  Session 02
            // Constructor Chaining
            // Class Vs  Struct
            // Inheirtance
            //  4-Polymorphism
            //4.1- Overloading
            // 4.2- Overriding
            #region Constructor Chaining
            //Car object01 = new Car(1,"M");
            //Console.WriteLine(object01);
            #endregion
            #region  Inheritance
            Chiled chiled = new Chiled(1, 2, 3);
            // Console.WriteLine(chiled);
            // X  v= new X();
            // Console.WriteLine(v);
            #endregion
            #region Overloading
            //int Result= Sum(1, 2);
            //Console.WriteLine();
            //Console.WriteLine("Rana");
            //Console.WriteLine('R');
            //Console.WriteLine(4);
            //Console.WriteLine(5.5F);
            //----------------
            //  Console.WriteLineString()
            //-----------------------------------------




            #endregion
            #region  Overriding
            //TypeA typeA = new TypeA(1);
            //typeA.A = 11;
            //typeA.MyFun01();// Iam Base [Parent]
            //typeA.MyFun02(); //TypeA:A = 11
            // TypeB typeB = new TypeB(1, 2);
            //Console.WriteLine(typeB);
            //-------------
            //typeB.MyFun01();
            // typeB.MyFun02();
            //Car[] a = new Car();
            #endregion




            #endregion
            #region Session 03
            #region  What is Binding?
            // Binding Is A behaviour
            //  Reference From Parent = Object from Chiled 
            //TypeA RefBase = new TypeB(1, 2);
            //RefBase.A = 11;
            //// RefBase.B =20 // Invalid 
            //RefBase.MyFun01();// Iam Base[Parent]
            //RefBase.MyFun02();// TypeB : A =11 , B=2
            //                  //-----------
            //TypeA typeA;
            //// typeA = new TypeA(1);
            // typeA = new TypeB(1, 2);
            ////typeA = new TypeC(1, 2, 3);
            //TypeB typeB1 = (TypeB) typeA;// Explicit Casting
            //Console.WriteLine(typeB1.A);
            //Console.WriteLine(typeB1.B);
            //--------------

            #endregion
            #region  Binding Is Behavior
            FullTimeEmployee fullTimeEmployee = new FullTimeEmployee()
            {
               Id = 10,
               Name = "Rana",
              Age = 22,
              Salary = 10000
            };
            PartTimeEmployee partTimeEmployee = new PartTimeEmployee()
            {
                Id = 10,
                Name = "Rana",
                Age = 22,
                HourRate = 120
            };

            // ProcessEmployee(fullTimeEmployee);





            //Employee02 employee = new FullTimeEmployee();
            //ProcessEmployee(employee);
            #endregion
            #region  Example 02 Binding
            TypeA typeA = new TypeC(1, 2, 3);
            typeA.A = 10;
            // typeA.B = 22; Invalid
            // typeA.C = 10; // Invalid
            //  typeA.MyFun01();// Static Binding => // Iam Base [Parent]
            // typeA.MyFun02

            //TypeB typeB = new TypeC(1, 2, 3);
            //typeB.A = 11;
            //typeB.B=12;
            //typeB.MyFun01();// Iam  Drived [Static Binding]
            //typeB.MyFun02();
            TypeA typeA1 = new TypeE(1, 2, 3, 4, 5); // Indirect Parent
            TypeB typeB1 = new TypeE(1, 2, 3, 4, 5); // Indirect Parent
            TypeC typeC1 = new TypeE(1, 2, 3, 4, 5); // Indirect Parent
            //-------------------
            // 
            //typeA1.MyFun02();
            //typeB1.MyFun02();
            //typeC1.MyFun02();
            Console.WriteLine(" After Break The Chain");
            TypeD typeD = new TypeD(1, 2, 3, 4);// dIrect Parent;
            typeD.MyFun02();
            #endregion
            #endregion





        }
    }
}
