﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Session_01_OOP.Encapsulation
{
    internal  struct Employee
    {
        #region Attributes
         // Encapsulation: Sperates Data Defintion [Attributes ] From Its  Use [Getter - Setter ] - Property]
        public int EmpId;//0 
        public decimal salary;//0
                              // Apply Property
                              //- Full Property

        //2-- Automatic Property
         // Compiler Will Generate Backing Field ( Hidden Private  Attribute )
         //public int Age { get; set; }
        public int age;
        public int Age
        {
            get { return age; }
            set { age = value; }
        }
        public decimal Salary
        {
             get { return salary; }
            set { salary = value; }
        }


        public string name;//null
                           // Getter 


        // Apply Property
        //-----------------------
        private int myVar;

        public int MyProperty
        {
            get { return myVar; }
            set { myVar = value; }
        }
        public int MyProperty1 { get; set; }

        private decimal deduction;
          public decimal Deduction
        {
             get { return Salary * .1m; }
        }
         public string GetName()
        {
            return name;
        }
         private  void SetName(string value)
        {
            name = value.Length>5 ?value.Substring(0,5): value ?? string.Empty;// Controll Value [Data Validation]
        }

        //public decimal Salary;//0
        #endregion
        #region Constructor
        //public Employee (int _id, string _name,decimal _salary)
        //{
        //    EmpId = _id;
        //    name = _name;
        //    salary = _salary;
        //}
        #endregion
        #region To String
        public override string ToString()
        {
            return $" Id : {EmpId}\n : Name is : {name} \n Salary = {Salary}";
        }
        #endregion


    }
}
