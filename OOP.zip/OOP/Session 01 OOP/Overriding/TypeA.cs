﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Session_01_OOP.Overriding
{
    internal class TypeA
    {
        //int a;
        // public int A
        //{
        //    get { return a; }
        //    set { a = value; }
        //}
        public int A {  get; set; }
        public TypeA(int _A)
        {
             A = _A;
        }
         public  void MyFun01()
        {
            Console.WriteLine("Iam Base Parent");
        }
         public virtual void MyFun02()
        {
            Console.WriteLine($" TypeA : A {A}");
        }
        
    }
}
