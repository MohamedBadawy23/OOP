﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Session_01_OOP.Overriding
{
    internal class TypeC :TypeB
    {
        public int C {  get; set; }
         public TypeC( int _A , int _B, int _C ):base(_A,_B)
        {
            C = _C;
        }
         public new void MyFun01()
        {
            Console.WriteLine("Iam Derived [GrandChild]");
        }
        public override void MyFun02()
        {
            Console.WriteLine($" TypeC : A {A} , B  : {B} : C={C}");
        }
    }
}
