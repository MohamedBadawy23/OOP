﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Session_01_OOP.Overriding
{
    internal class TypeB:TypeA
    {
         public int B {  get; set; }
         public TypeB(int _A,int _B):base(_A)
        {
            B = _B;
        }
         // Static Binding [ EarlyBinding ]
          // Compiler Will Bind Funcation Call Based On  Reference Not Object
          // At Compilation Time 
         public new void MyFun01() //=> new version  from Myfun01
        {
            Console.WriteLine(" Iam Drevied [Chiled]");
        }
        // Aplly Over riding Using  override ( By using public - Virtiul)
         // Dynamic Binding [Late Binding ]
          // Clr Will Bind Function Call  Based on Object  Not Refernce 

        // At Run Time
        public override void  MyFun02()
        {
            Console.WriteLine($" TypeB : A {A}\n  B  : {B}");
        }
    }
}
