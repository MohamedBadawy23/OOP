﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Session_01_OOP.Overriding
{
    internal class TypeE:TypeD
    {
        public int E { get; set; }
        public TypeE(int _A, int _B, int _C, int _D,int _E) : base(_A, _B, _C,_D)
        {
            E = _E;
        }
        public new void MyFun01()
        {
            Console.WriteLine("Iam Derived [GrandChild03]");
        }
        public override void MyFun02()
        {
            Console.WriteLine($" TypeB : A {A} , B  : {B} : C={C} :D ={D} : E ={E}");
        }
    }
}
