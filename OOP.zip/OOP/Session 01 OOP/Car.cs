﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Session_01_OOP
{
    internal class Car
    {
        //-Attributes [Filed]
        //2- Properties (Full Property- Automatic Property- Index)
        //3-Functions( Constructor - Getter Setter-Methods)
        //4- Event 
        //-------------
        // Allowed Access Modifiers Inside The Class
        //- Private
        //- Private Protected
        //- Protected
        // Internal
        // Internal Protected
        // Public
        //-------------
        // Default Access Modifier For Class [Internal]
        #region  Attributes & Properties
        private int Id { get; set; } // Automatic Property
        private string Model { get; set; }

        private double Speed { get; set; }
        // Full Property For id 
        //public int Id
        //{
        //    get { return id; }
        //    set { id = value; }

        //}
        #endregion
        #region  Mthods
        public override string ToString()
        {
            return $" car id :{Id}\n  Car Model is : {Model}:\n Car Speed {Speed}";
        }
        #endregion
        
        // If There is No User Defined Constructor  The Compiler Will Generate Parameterless Constructor => Do Nothing
        

         public Car ( int _id, string _model, double _speed )
        {
             Id = _id ;
            
             Model = _model ;
            Speed = _speed ;
            Console.WriteLine("Constructor 1");
            
        }
         //OverLoading
          public Car ( int _id, String _model):this(_id, _model , 100)
        {
            //Id = _id;
            //Model = _model;
            // Speed = 150;
            Console.WriteLine("Constructor 2");
        }
       
        public Car ( int _id):this(_id , "BMW",200)
        {
            // Id = _id;
            //Model = "BMW";
            //Speed = 200;
            Console.WriteLine("Constructor 3");
        }
         // If You Defined A user Defined Constructor
          // Compiler Will No Longer Genrate The Parameterless Constructor
           



    }
}
