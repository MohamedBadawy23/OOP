﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Session_01_OOP.Association_Composition
{
    internal class Order
    {
         // 1- Asscciation Compostion(Has A )
         //Order Has A Item

         public int Id { get; set; }    
        public string BuyerEmail { get; set; }
         public  decimal SubTotal { get; set; }
         public OderItem[] Items { get; set; }
         public Order (  string _BuyerEmail , OderItem[] _Items)
        {
            BuyerEmail= _BuyerEmail;
            Items= _Items;
        }

    }
}
