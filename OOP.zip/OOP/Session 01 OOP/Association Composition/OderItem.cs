﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Session_01_OOP.Association_Composition
{
    internal class OderItem
    {
         //1- Association Composotion RelationShip ( Has A )
          // OrderItem Has An Item
         public int Id { get; set; }
         public Product Product { get; set; }
         public decimal Price { get; set; }
         public int Quantity { get; set; }
         public OderItem( Product _product)
        {
         Product= _product;
        }
    }
}
