﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Common03
{
    internal class TypeB:TypeA
    {
         public void Test01()
        {
         // X is  inhearted  private
         // Y is Inheearted Private
          // Z is  Inhearted Internal 
  
        }
    }
}
