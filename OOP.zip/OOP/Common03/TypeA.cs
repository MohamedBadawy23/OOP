﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Common03
{
    internal class TypeA
    {
        private  int X; // Private
         int Y; // private
        internal protected int Z; // internal
    }
}
