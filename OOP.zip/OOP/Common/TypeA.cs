﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Common
{
    #region Name Space
    // what Can be Written Inside The Namespace
    //1- Class
    //2- Struct[ stand For Structure]
    //3- Interface
    //4- Enum
    // Allowed Access Modifiers Inside The Namespace
    //1- Internal ( Default Access Modifier)
    //2- public
    #endregion
     

    //public class TypeA
    //{
    //    private int X;
    //    internal int Y;
    //    public int Z;

    //     public void print()
    //    {
    //        Console.WriteLine(X);
    //    }


    //    #region What We Can Write Inside The Class or Struct 
    //    //-Attributes [Filed]
    //    //2- Properties (Full Property- Automatic Property- Index)
    //    //3-Functions( Constructor - Getter Setter-Methods)
    //    //4- Event 
    //    //-------------
    //    // Allowed Access Modifiers Inside The Struct
    //    //1-Private
    //    //2- Internal 
    //    //2- Public 
    //    // Allowed Access Modifiers Inside The Class
    //    //- Private
    //    //- Private Protected
    //    //- Protected
    //    // Internal
    //    // Internal Protected
    //    // Public
    //    //-------------
    //    //Default Access Modifiers Inside The Class Or The Struct  Is "Private"
    //    //1-Private
    //    //2- Internal 
    //    //2- Public 
    //    // Allowed Access Modifiers Inside The Class
    //    //- Private
    //    //- Private Protected
    //    //- Protected
    //    // Internal
    //    // Internal Protected
    //    // Public
    //     // Degault Access Modifiers Inside The Interface  Is "Public"



    //    #endregion
    //    #region Interface 
    //    //-     Signature For Method
    //    //- Signature For Property

    //    //- Default Implemented Property (c#8 ( .net 3.1 2019)
    //    //Default Implemented Method (c#8 ( .net 3.1 2019)
    //    // Allowed Access Modifiers Inside The nterface 
    //    #endregion


    }
}
